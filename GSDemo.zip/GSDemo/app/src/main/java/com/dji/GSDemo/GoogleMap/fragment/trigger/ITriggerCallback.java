package com.dji.GSDemo.GoogleMap.fragment.trigger;

import dji.common.mission.waypointv2.Action.WaypointTrigger;

public interface ITriggerCallback {
    WaypointTrigger getTrigger();
}
