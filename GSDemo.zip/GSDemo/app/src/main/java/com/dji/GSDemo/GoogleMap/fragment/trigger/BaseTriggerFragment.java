package com.dji.GSDemo.GoogleMap.fragment.trigger;

import androidx.fragment.app.Fragment;

public class BaseTriggerFragment extends Fragment {
    protected int size;

    public void setSize(int size) {
        this.size = size;
    }
}
